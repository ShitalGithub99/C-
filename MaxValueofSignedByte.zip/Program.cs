using System;



public class Program //DO NOT change the class name
{
public static void Main(string[] args){
sbyte number=125;
Console.WriteLine("Value of number: {0}", number);
Console.WriteLine("Largest value stored in a signed byte : {0}", sbyte.MaxValue);


}

}